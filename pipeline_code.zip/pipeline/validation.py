import logging
from typing import Set

import pandera.pyspark as pa
from pandera.pyspark import DataFrameSchema, Column
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, DoubleType, DateType

from config import config

logger = logging.getLogger(__name__)

c = config.schema_
f = config.features

transactions_schema = DataFrameSchema(
    columns={
        c.customer_id: Column(StringType(), nullable=False),
        c.transaction_id: Column(StringType(), nullable=False),
        c.transaction_date: Column(DateType(), nullable=False),
        c.credit_debit_code: Column(
            StringType(),
            checks=pa.Check.isin([f.credit_code, f.debit_code]),
            nullable=False,
        ),
        c.transaction_type_code: Column(StringType(), nullable=False),
        c.transaction_value: Column(
            DoubleType(),
            checks=pa.Check.greater_than_or_equal_to(0),
            nullable=False,
        ),
    }
)


def check_referential_integrity(transactions_df: DataFrame, transaction_types_df: DataFrame) -> None:
    """Verify every transaction_type_code in transactions exists in TransactionType."""
    known_codes: Set[str] = {
        row[c.transaction_type_code]
        for row in transaction_types_df.select(c.transaction_type_code).collect()
    }
    unknown = (
        transactions_df
        .select(c.transaction_type_code)
        .distinct()
        .filter(~F.col(c.transaction_type_code).isin(list(known_codes)))
        .collect()
    )
    if unknown:
        unknown_codes = [r[c.transaction_type_code] for r in unknown]
        raise ValueError(f"Unknown transaction_type_codes found: {unknown_codes}")


def check_for_new_columns(transactions_df: DataFrame) -> None:
    """Log a warning if the source data contains columns not present in the schema."""
    known = set(transactions_schema.columns.keys())
    incoming = set(transactions_df.columns)
    new_cols = incoming - known
    if new_cols:
        logger.warning("New columns detected in source data: %s", new_cols)


def validate_transactions(transactions_df: DataFrame, transaction_types_df: DataFrame) -> None:
    """Run all validation checks against the raw transactions DataFrame.
    """
    logger.info("Running validation checks")
    check_for_new_columns(transactions_df)
    transactions_schema.validate(transactions_df)
    check_referential_integrity(transactions_df, transaction_types_df)
    logger.info("All validation checks passed")
